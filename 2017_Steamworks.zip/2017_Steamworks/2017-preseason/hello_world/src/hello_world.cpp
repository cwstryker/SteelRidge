//============================================================================
// Name        : hello_world.cpp
// Author      : Chad Stryker
// Version     :
// Copyright   : 2-Clause BCD Licence
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
using namespace std;

int main() {
	cout << "!!!Hello World!!!" << endl; // prints !!!Hello World!!!
	cout << "cwstryker was here too!" << endl;
	return 0;
}
